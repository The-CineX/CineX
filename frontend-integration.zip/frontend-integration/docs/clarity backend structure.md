├── contracts/
│ ├── CineX-project.clar
│ ├── CineX-rewards-sip09.clar
│ ├── crowdfunding-module.clar
│ ├── crowdfunding-module-traits.clar
│ ├── escrow-module.clar
│ ├── escrow-module-trait.clar
│ ├── film-verification-module.clar
│ ├── film-verification-module-trait.clar
│ ├── rewards-module.clar
│ ├── rewards-module-trait.clar
│ ├── rewards-nft-trait.clar
│ └── verification-fee-mgt-enhancement-extension.clar
│
├── Clarinet.toml
│
├── vitest.config.js
│
└── .vscode/
└── tasks.json


