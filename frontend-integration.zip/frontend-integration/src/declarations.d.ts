// TypeScript module declaration for @stacks/connect (no types provided)
declare module '@stacks/connect';
